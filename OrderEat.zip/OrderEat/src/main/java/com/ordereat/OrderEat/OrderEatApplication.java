package com.ordereat.OrderEat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderEatApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderEatApplication.class, args);
	}

}
