package com.ordereat.OrderEat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderEatApplicationTests {

	@Test
	void contextLoads() {
	}

}
